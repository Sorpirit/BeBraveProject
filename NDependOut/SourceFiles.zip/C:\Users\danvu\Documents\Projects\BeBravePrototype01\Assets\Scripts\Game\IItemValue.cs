namespace Game
{
    public interface IItemValue
    {
        void SetItemValue(int value);
    }
}