using DG.Tweening;

namespace UI
{
    public interface ICameraEffects
    {
        public Tween ZoomIn();
        public Tween ZoomOut();
    }
}