namespace Game
{
    public interface IEnemyValues
    {
        void SetDamage(int value);
        void SetHealth(int value);
    }
}