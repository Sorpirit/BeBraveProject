using Core.PlayerSystems;

namespace Core.RoomsSystem
{
    public interface IRoomContent
    {
        void Enter(PlayerPawn player);
    }
}