namespace Core.PlayerSystems
{
    public interface IDamageable
    {
        void TakeDamage(DamageInfo damageInfo);
    }
}