namespace Core.CardSystem.Data
{
    /// <summary>
    /// Data container for that describes stats of the card(aka Damage of the Trap).
    /// </summary>
    public interface ICardDescription { }
}